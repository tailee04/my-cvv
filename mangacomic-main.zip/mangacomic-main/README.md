# GARDENTOON
Sơ đồ database
![Hình ảnh sơ đồ quan hệ Database](./README/img/1.png)